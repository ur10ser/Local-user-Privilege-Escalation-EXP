// stdafx.h : ��׼ϵͳ�����ļ��İ����ļ���
// ���Ǿ���ʹ�õ��������ĵ�
// �ض�����Ŀ�İ����ļ�
//

#ifdef ARRAYSIZE
#define countof(a) (ARRAYSIZE(a)) // (sizeof((a))/(sizeof(*(a))))
#else
#define countof(a) (sizeof((a)) / (sizeof(*(a))))
#endif


#pragma once

#include "targetver.h"
#include <comdef.h>
#include <ComSvcs.h>
//#include "mystdhook.h"


//#include <stdio.h>
//#include <tchar.h>


//
//
//// TODO:  �ڴ˴����ó�����Ҫ������ͷ�ļ�
//
//struct __declspec(uuid("8cec595b-07a1-11d9-b15e-000d56bfe6ee"))
//IHxInteractiveUser : public IUnknown
//{
//public:
//	
//
//	virtual	HRESULT  STDMETHODCALLTYPE Execute(
//		__RPC__in LPCWSTR pcUrl);
//
//
//
//};
//
//
//_COM_SMARTPTR_TYPEDEF(IHxInteractiveUser, __uuidof(IHxInteractiveUser));



MIDL_INTERFACE("8CEC592C-07A1-11D9-B15E-000D56BFE6EE")
IHxHelpPaneServer : public IUnknown{
public:

	virtual    HRESULT STDMETHODCALLTYPE DisplayTask(__RPC__in BSTR bstrUrl);
	virtual 	HRESULT STDMETHODCALLTYPE DisplayContents(__RPC__in BSTR bstrUrl);
	virtual 	HRESULT STDMETHODCALLTYPE DisplaySearchResults(__RPC__in BSTR bstrSearchQuery);
	virtual 	HRESULT STDMETHODCALLTYPE Execute(__RPC__in LPWSTR pcUrl);
};


_COM_SMARTPTR_TYPEDEF(IHxHelpPaneServer, __uuidof(IHxHelpPaneServer));


const unsigned long OBJREF_SIGNATURE = 0x574f454d;
const unsigned long OBJREF_STANDARD = 0x1;
const unsigned long OBJREF_HANDLER = 0x2;
const unsigned long OBJREF_CUSTOM = 0x4;
const unsigned long SORF_NOPING = 0x1000;

typedef LUID OXID;
typedef LUID OID;
typedef GUID	IPID;

typedef struct tagDUALSTRINGARRAY    {
	unsigned short wNumEntries;     // Number of entries in array.
	unsigned short wSecurityOffset; // Offset of security info.
	unsigned short aStringArray[1];
} DUALSTRINGARRAY;

typedef struct tagSTDOBJREF    {
	DWORD   flags;
	DWORD   cPublicRefs;
	OXID           oxid;
	OID            oid;
	IPID           ipid;
} STDOBJREF;

typedef struct tagOBJREF    {
	unsigned long signature;//MEOW
	unsigned long flags;
	GUID          iid;
	union        {
		struct            {
			STDOBJREF       std;
			DUALSTRINGARRAY saResAddr;
		} u_standard;
		struct            {
			STDOBJREF       std;
			CLSID           clsid;
			DUALSTRINGARRAY saResAddr;
		} u_handler;
		struct            {
			CLSID           clsid;
			unsigned long   cbExtension;
			unsigned long   size;
			ULONGLONG pData;
		} u_custom;
	} u_objref;
} OBJREF;


struct __declspec(align(4)) IUnknownVtbl
{
	HRESULT(__stdcall *QueryInterface)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(__stdcall *AddRef)();
	ULONG(__stdcall *Release)();
};

struct SHashChain
{
	LPVOID  pNext;
	LPVOID  pPrev;
};
struct tagSPSCache
{
	SHashChain clientPSChain;
	SHashChain serverPSChain;
};

struct  CContextPropList
{
	DWORD _Max;
	DWORD _iFirst;
	int _iLast;
	DWORD _Count;
	DWORD _cCompareProps;
	DWORD _Hash;
	DWORD _slotIdx;
	ULONGLONG *_pProps;
	DWORD *_pSlots;
	ULONGLONG *_pCompareBuffer;
	ULONGLONG *_pIndex;
};


struct CMyObjectContext 
{
	IUnknownVtbl *Selfvfptr;
	IUnknownVtbl *IMarshalEnvoyvfptr;
	IUnknownVtbl *IMarshalvfptr;
	IUnknownVtbl *IComThreadingInfovfptr;
	IUnknownVtbl *IContextCallbackvfptr;
	IUnknownVtbl *IAggregatorvfptr;
	IUnknownVtbl *IGetContextIdvfptr;
	DWORD _cRefs;
	DWORD  _cUserRefs;
	DWORD  _cInternalRefs;
	DWORD  _dwFlags;
	SHashChain _propChain;
	SHashChain _uuidChain;
	LONGLONG _pifData;
	LONGLONG _MarshalSizeMax;
	LONGLONG _pApartment;
	DWORD _dwHashOfId;
	_GUID _contextId;
	LONGLONG _urtCtxId;
	tagSPSCache _PSCache;
	LONGLONG _pMarshalProp;
	LONGLONG _cReleaseThreads;
	CContextPropList _properties;
	LONGLONG _pMtsContext;
	LONGLONG _pContextLife;
	LONGLONG _pConnectionMgr;
};



class IMyUnknown
{
public:

	HRESULT STDMETHODCALLTYPE QueryInterface(
		/* [in] */ REFIID riid,
		/* [iid_is][out] */ _COM_Outptr_ void __RPC_FAR *__RPC_FAR *ppvObject);

	ULONG STDMETHODCALLTYPE AddRef(void);

	ULONG STDMETHODCALLTYPE Release(void);
};

  

MIDL_INTERFACE("00000008-0000-0000-c000-000000000046")
IProxyManager: public IUnknown{
public:
	virtual    HRESULT STDMETHODCALLTYPE CreateServer(REFCLSID rclsid, DWORD clsctx, void *pv) = 0;
	virtual    HRESULT STDMETHODCALLTYPE IsConnected(void) = 0;
	virtual    HRESULT STDMETHODCALLTYPE LockConnection(BOOL fLock, BOOL fLastUnlockReleases) = 0;
	virtual    void STDMETHODCALLTYPE Disconnect(void) = 0;
	virtual IUnknown __RPC_FAR *STDMETHODCALLTYPE GetConnectionStatus(void) = 0;
	virtual void STDMETHODCALLTYPE SetMapping(void __RPC_FAR *pv) = 0;
	virtual void* __RPC_FAR *STDMETHODCALLTYPE GetMapping(void) = 0;
	virtual IObjContext __RPC_FAR *STDMETHODCALLTYPE GetServerObjectContext(void) = 0;
	virtual    HRESULT STDMETHODCALLTYPE EstablishIID(_GUID *iid, void **ppv) = 0;
	virtual    HRESULT STDMETHODCALLTYPE GetWrapperForContext(IObjContext *pCtx, REFCLSID riid, void **ppv) = 0;
	virtual    HRESULT STDMETHODCALLTYPE Connect(_GUID oid, _GUID *rclsid) = 0;



};
struct  OXIDEntry
{
	OXIDEntry *_pNext;
	OXIDEntry *_pPrev;
	unsigned int _dwPid;
	unsigned int _dwTid;
	_GUID _moxid;
	unsigned __int64 _mid;
	_GUID _ipidRundown;
	unsigned int _dwFlags;
	HWND__ *_hServerSTA;
	ULONGLONG *_pParentApt_CComApartment;
	ULONGLONG *volatile _pRpc_CChannelHandle;
	void *_pAuthId;
	tagDUALSTRINGARRAY *_pBinding;
	unsigned int _dwAuthnHint;
	unsigned int _dwAuthnSvc;
	ULONGLONG *_pMIDEntry;
	ULONGLONG *_pRUSTA_IRemUnknown;
	int _cRefs;
	void *_hComplete;
	int _cCalls;
	int _cResolverRef;
	unsigned int _dwExpiredTime;
	ULONGLONG _tagCOMVERSION;
	unsigned int _ulMarshaledTargetInfoLength;
	char *_pMarshaledTargetInfo;
};


struct tagIPIDEntry
{
	tagIPIDEntry *pNextIPID;
	unsigned int dwFlags;
	unsigned int cStrongRefs;
	unsigned int cWeakRefs;
	unsigned int cPrivateRefs;
	void *pv;
	IUnknown *pStub;
	OXIDEntry *pOXIDEntry;
	_GUID ipid;
	_GUID iid;
	ULONGLONG *pChnl_CCtxComChnl;
	ULONGLONG *pIRCEntry;
	tagIPIDEntry *pOIDFLink;
	tagIPIDEntry *pOIDBLink;
};

struct  IMyMarshalVtbl
{
	HRESULT(STDMETHODCALLTYPE *QueryInterface)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *AddRef)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *Release)(void* SelfPtr);


	HRESULT(STDMETHODCALLTYPE *GetUnmarshalClass)(void* SelfPtr,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags,
		/* [annotation][out] */
		_Out_  CLSID *pCid);

	HRESULT(STDMETHODCALLTYPE *GetMarshalSizeMax)(void* SelfPtr,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags,
		/* [annotation][out] */
		_Out_  DWORD *pSize);

	HRESULT(STDMETHODCALLTYPE *MarshalInterface)(void* SelfPtr,
		/* [annotation][unique][in] */
		_In_  IStream *pStm,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags);

	HRESULT(STDMETHODCALLTYPE *UnmarshalInterface)(void* SelfPtr,
		/* [annotation][unique][in] */
		_In_  IStream *pStm,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][out] */
		_Outptr_  void **ppv);

	HRESULT(STDMETHODCALLTYPE *ReleaseMarshalData)(void* SelfPtr,
		/* [annotation][unique][in] */
		_In_  IStream *pStm);

	HRESULT(STDMETHODCALLTYPE *DisconnectObject)(void* SelfPtr,
		/* [annotation][in] */
		_In_  DWORD dwReserved);
};


struct  IMyCStdIdentityVtbl
{
	HRESULT(STDMETHODCALLTYPE *QueryInterface)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *AddRef)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *Release)(void* SelfPtr);


	HRESULT(STDMETHODCALLTYPE *GetUnmarshalClass)(void* SelfPtr,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags,
		/* [annotation][out] */
		_Out_  CLSID *pCid);

	HRESULT(STDMETHODCALLTYPE *GetMarshalSizeMax)(void* SelfPtr,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags,
		/* [annotation][out] */
		_Out_  DWORD *pSize);

	HRESULT(STDMETHODCALLTYPE *MarshalInterface)(void* SelfPtr,
		/* [annotation][unique][in] */
		_In_  IStream *pStm,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags);

	HRESULT(STDMETHODCALLTYPE *UnmarshalInterface)(void* SelfPtr,
		/* [annotation][unique][in] */
		_In_  IStream *pStm,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][out] */
		_Outptr_  void **ppv);

	HRESULT(STDMETHODCALLTYPE *ReleaseMarshalData)(void* SelfPtr,
		/* [annotation][unique][in] */
		_In_  IStream *pStm);

	HRESULT(STDMETHODCALLTYPE *DisconnectObject)(void* SelfPtr,
		/* [annotation][in] */
		_In_  DWORD dwReserved);
	ULONGLONG *_pZero;
	HRESULT(STDMETHODCALLTYPE *CRpcChannelBuffer_QueryInterface)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *CRpcChannelBuffer_AddRef)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *CRpcChannelBuffer_Release)(void* SelfPtr);

	HRESULT(STDMETHODCALLTYPE *GetBuffer)(void* SelfPtr,
		/* [annotation][out][in] */
		_Inout_  RPCOLEMESSAGE *pMessage,
		/* [annotation][in] */
		_In_  REFIID riid);

	HRESULT(STDMETHODCALLTYPE *SendReceive)(void* SelfPtr,
		/* [annotation][out][in] */
		_Inout_  RPCOLEMESSAGE *pMessage,
		/* [annotation][out] */
		_Out_opt_  ULONG *pStatus);

	HRESULT(STDMETHODCALLTYPE *FreeBuffer)(void* SelfPtr,
		/* [annotation][out][in] */
		_Inout_  RPCOLEMESSAGE *pMessage);

	HRESULT(STDMETHODCALLTYPE *GetDestCtx)(void* SelfPtr,
		/* [annotation][out] */
		_Out_  DWORD *pdwDestContext,
		/* [annotation][out] */
		_Outptr_result_maybenull_  void **ppvDestContext);
	//IsConnected
	HRESULT(STDMETHODCALLTYPE *CStdAsyncStubBuffer_Synchronize_Reset)(void* SelfPtr);
	HRESULT(STDMETHODCALLTYPE *CRpcChannelBuffer_GetProtocolVersion)(void* SelfPtr, unsigned long * Version);
	HRESULT(STDMETHODCALLTYPE *CAptRpcChnl_Send)(void* SelfPtr, struct tagRPCOLEMESSAGE * pMessage, unsigned long * pStatus);
	HRESULT(STDMETHODCALLTYPE *CAptRpcChnl_Receive)(void* SelfPtr, struct tagRPCOLEMESSAGE * pMessage, unsigned long * pStatus);

	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_Cancel)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_GetCallContext)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage, _GUID * iid, void **ppvDestContext);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_GetDestCtxEx)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage, unsigned int * pdwDestContext, void ** ppvDestContext);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_GetState)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage, unsigned int * State);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_RegisterAsync)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage, IAsyncManager *Manager);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_SendReceive2)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage, unsigned int * pStatus);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_Send2)(void* SelfPtr, tagRPCOLEMESSAGE * pMessage, unsigned int * pStatus);
	HRESULT(STDMETHODCALLTYPE *IRpcChannelBuffer3_Receive2)(void* SelfPtr, tagRPCOLEMESSAGE *, unsigned int, unsigned int * pStatus);
	HRESULT(STDMETHODCALLTYPE *CCtxComChnl_ContextInvoke)(void* SelfPtr, tagRPCOLEMESSAGE *pMessage, IRpcStubBuffer *pStub, tagIPIDEntry *pIPIDEntry, unsigned int *pdwFault);
	HRESULT(STDMETHODCALLTYPE *CCtxComChnl_GetBuffer2)(void* SelfPtr,
		/* [annotation][out][in] */
		_Inout_  RPCOLEMESSAGE *pMessage,
		/* [annotation][in] */
		_In_  REFIID riid);
	HRESULT(STDMETHODCALLTYPE *CCtxComChnl_scalar_deleting_destructor)(void* SelfPtr);
	HRESULT(STDMETHODCALLTYPE *CAptRpcChnl_Send2)(void* SelfPtr, struct tagRPCOLEMESSAGE * pMessage, unsigned long * pStatus);
	HRESULT(STDMETHODCALLTYPE *CStdIdentity_QueryInterface)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_AddRef)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_Release)(void* SelfPtr);
	HRESULT(STDMETHODCALLTYPE *Set)(void* SelfPtr,
		/* [annotation][in] */
		_In_  IUnknown *pPrx,
		/* [annotation][in] */
		_In_  RPCOPT_PROPERTIES dwProperty,
		/* [annotation][in] */
		_In_  ULONG_PTR dwValue);

	HRESULT(STDMETHODCALLTYPE *Query)(void* SelfPtr,
		/* [annotation][in] */
		_In_  IUnknown *pPrx,
		/* [annotation][in] */
		_In_  RPCOPT_PROPERTIES dwProperty,
		/* [annotation][out] */
		_Out_  ULONG_PTR *pdwValue);


	HRESULT(STDMETHODCALLTYPE *CStdIdentity_QueryInterface2)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_AddRef2)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_Release2)(void* SelfPtr);

	HRESULT(STDMETHODCALLTYPE *QueryBlanket)(void* SelfPtr,
		/* [annotation][in] */
		_In_  IUnknown *pProxy,
		/* [annotation][out] */
		_Out_  DWORD *pAuthnSvc,
		/* [annotation][out] */
		_Out_opt_  DWORD *pAuthzSvc,
		/* [annotation][out] */
		__RPC__deref_out_opt  OLECHAR **pServerPrincName,
		/* [annotation][out] */
		_Out_opt_  DWORD *pAuthnLevel,
		/* [annotation][out] */
		_Out_opt_  DWORD *pImpLevel,
		/* [annotation][out] */
		_Outptr_result_maybenull_  void **pAuthInfo,
		/* [annotation][out] */
		_Out_opt_  DWORD *pCapabilites);

	HRESULT(STDMETHODCALLTYPE *SetBlanket)(void* SelfPtr,
		/* [annotation][in] */
		_In_  IUnknown *pProxy,
		/* [annotation][in] */
		_In_  DWORD dwAuthnSvc,
		/* [annotation][in] */
		_In_  DWORD dwAuthzSvc,
		/* [annotation][in] */
		__RPC__in_opt  OLECHAR *pServerPrincName,
		/* [annotation][in] */
		_In_  DWORD dwAuthnLevel,
		/* [annotation][in] */
		_In_  DWORD dwImpLevel,
		/* [annotation][in] */
		_In_opt_  void *pAuthInfo,
		/* [annotation][in] */
		_In_  DWORD dwCapabilities);

	HRESULT(STDMETHODCALLTYPE *CopyProxy)(void* SelfPtr,
		/* [annotation][in] */
		_In_  IUnknown *pProxy,
		/* [annotation][out] */
		_Outptr_  IUnknown **ppCopy);
	HRESULT(STDMETHODCALLTYPE *CStdIdentity_QueryInterface3)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_AddRef3)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_Release3)(void* SelfPtr);

	HRESULT(STDMETHODCALLTYPE *CStdIdentity_CreateCall)(void* SelfPtr, _GUID *asyncIID, IUnknown *pCtrlUnk, _GUID *objIID, IUnknown **ppUnk);

	HRESULT(STDMETHODCALLTYPE *CStdIdentity_QueryInterface4)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_AddRef4)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *CStdIdentity_Release4)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *AllowForegroundTransfer)(void* SelfPtr, void *lpvReserved);

};
typedef HRESULT(STDMETHODCALLTYPE *CreateChannelFunc)(void* SelfPtr, OXIDEntry *pOXIDEntry, unsigned int dwFlags, const _GUID *ripid, const  _GUID *riid, IRpcChannelBuffer **ppChnl);
typedef HRESULT(STDMETHODCALLTYPE *CreateProxyFunc)(void* SelfPtr,
	/* [annotation][in] */
	_In_  IUnknown *pUnkOuter,
	/* [annotation][in] */
	_In_  REFIID riid,
	/* [annotation][out] */
	_Outptr_  IRpcProxyBuffer **ppProxy,
	/* [annotation][out] */
	_Outptr_  void **ppv);

typedef HRESULT(STDMETHODCALLTYPE *CreateStubFunc)(void* SelfPtr,
	/* [annotation][in] */
	_In_  REFIID riid,
	/* [annotation][unique][in] */
	_In_opt_  IUnknown *pUnkServer,
	/* [annotation][out] */
	_Outptr_  IRpcStubBuffer **ppStub) ;

typedef HRESULT(STDMETHODCALLTYPE *CStdMarshal_MarshalInterface)(void* SelfPtr, IStream *pStm, const _GUID riid, void *pv, unsigned int dwDestCtx, void *pvDestCtx, unsigned int mshlflags);


typedef HRESULT(STDMETHODCALLTYPE *WrapperMarshalObject)(IStream *pStm, const IID *riid, void *pUnk, unsigned int dwDestCtx, void *pvDestCtx, unsigned int mshlflags);


typedef  struct IMyCStdMarshalHookFunctionList
{
	ULONGLONG PCreateChannelFuncAddr;
	ULONGLONG PCreateProxyFuncAddr;
	ULONGLONG PCreateStubFuncAddr;
	ULONGLONG PCStdMarshal_MarshalInterface;
	ULONGLONG PWrapperMarshalObject;
} *PIMyCStdMarshalHookFunctionList;


struct IMyCStdIdentityHook;
class CMyClassCStdIdentity;


typedef  struct  IMyIUnknownVtbl
{
	HRESULT(STDMETHODCALLTYPE *QueryInterface)(void* SelfPtr,
		/* [in] */ const _GUID* riid,
		/* [iid_is][out] */ void** ppvObject);
	ULONG(STDMETHODCALLTYPE *AddRef)(void* SelfPtr);
	ULONG(STDMETHODCALLTYPE *Release)(void* SelfPtr);
} *PIMyIUnknownVtbl;
typedef struct  IMyIUnknown
{
	void *  _selfVtbl;
} *PIMyIUnknown;

typedef struct  IMyIMyMarshal
{
	IMyMarshalVtbl *  _selfMarshalVtbl;
} *PIMyIMyMarshal;



typedef struct  IMyIUnknownReal
{
	IMyIUnknownVtbl*  _selfVtbl;
} *PIMyIUnknownReal;


typedef struct   IMyProxyManagers 
{
	IMyIUnknown  pIProxyManagers;
} *PIMyProxyManagers;

struct CStdMarshal_DiscSinkNode
{
	CStdMarshal_DiscSinkNode *pNext;
	CStdMarshal_DiscSinkNode *pPrev;
	ULONGLONG *pSink_IDisconnectSink;
	void *pvCookie;
};

typedef struct  CStdMarshal
{

	IMyIMyMarshal pIMarshal2;
	unsigned int _dwFlags;
	int _cIPIDs;
	tagIPIDEntry *_pFirstIPID;
	IMyCStdIdentityHook*  _pStdId;
	ULONGLONG *_pChnl_CCtxComChnl;
	_GUID _clsidHandler;
	int _cNestedCalls;
	int _cTableRefs;
	unsigned int _dwMarshalTime;
	ULONGLONG *_pSecureRemUnk_IRemUnknown;
	IUnknown *_pAsyncRelease;
	ULONGLONG *_pCtxEntryHead_CtxEntry;
	ULONGLONG *_pCtxFreeList_CtxEntry;
	_RTL_CRITICAL_SECTION _csCtxEntry;
	int _fCsInitialized;
	ULONGLONG *_pPS_CPolicySet;
	ULONGLONG *_pID_CIDObject;
	ULONGLONG *_pRefCache_CRefCache;
	CStdMarshal_DiscSinkNode _discHead_CStdMarshal_DiscSinkNode;
	unsigned int _dwLastCallTime;
} *PCStdMarshal;


typedef struct  CClientSecurity
{
	IMyIUnknown  pIClientSecurity;
	IMyCStdIdentityHook*  _pStdId;
} *PCClientSecurity;

typedef struct  CRpcOptions
{
	IMyIUnknown  pIRpcOptions;
	IMyCStdIdentityHook*  _pStdId;
	IMyIUnknown *_pUnkOuter;
} *PCRpcOptions;


typedef struct  IMyCallFactory
{
	IMyIUnknown  pIICallFactory;
} *PIMyCallFactory;

typedef struct  IMyForegroundTransfer
{
	IMyIUnknown  pIForegroundTransfer;
} *PIMyForegroundTransfer;




typedef struct CStdIdentity_CInternalUnk{
	IMyIUnknownVtbl*  pIInternalUnknown;
	IMyIUnknownVtbl* pIMultiQI_IMultiQI;
} *PCStdIdentity_CInternalUnk;


typedef interface IMyCStdWrapperMarshal{

public:
	virtual HRESULT STDMETHODCALLTYPE QueryInterface(
		/* [in] */ REFIID riid,
		/* [iid_is][out] */ _COM_Outptr_ void __RPC_FAR *__RPC_FAR *ppvObject) = 0;

	virtual ULONG STDMETHODCALLTYPE AddRef(void) = 0;

	virtual ULONG STDMETHODCALLTYPE Release(void) = 0;

	virtual HRESULT STDMETHODCALLTYPE GetUnmarshalClass(
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags,
		/* [annotation][out] */
		_Out_  CLSID *pCid) = 0;

	virtual HRESULT STDMETHODCALLTYPE GetMarshalSizeMax(
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags,
		/* [annotation][out] */
		_Out_  DWORD *pSize) = 0;

	virtual HRESULT STDMETHODCALLTYPE MarshalInterface(
		/* [annotation][unique][in] */
		_In_  IStream *pStm,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][unique][in] */
		_In_opt_  void *pv,
		/* [annotation][in] */
		_In_  DWORD dwDestContext,
		/* [annotation][unique][in] */
		_Reserved_  void *pvDestContext,
		/* [annotation][in] */
		_In_  DWORD mshlflags) = 0;

	virtual HRESULT STDMETHODCALLTYPE UnmarshalInterface(
		/* [annotation][unique][in] */
		_In_  IStream *pStm,
		/* [annotation][in] */
		_In_  REFIID riid,
		/* [annotation][out] */
		_Outptr_  void **ppv) = 0;

	virtual HRESULT STDMETHODCALLTYPE ReleaseMarshalData(
		/* [annotation][unique][in] */
		_In_  IStream *pStm) = 0;

	virtual HRESULT STDMETHODCALLTYPE DisconnectObject(
		/* [annotation][in] */
		_In_  DWORD dwReserved) = 0;
	virtual HRESULT STDMETHODCALLTYPE GetStaticInfo(IUnknown *SelfPtr, void *pInterceptor) = 0;
};

class CMyCStdWrapperMarshal : public IMyCStdWrapperMarshal{

public:
	unsigned int _dwState;
	unsigned int _cRefs;
	unsigned int _cCalls;
	unsigned int _cIFaces;
	IUnknown *_pIFaceHead;
	IUnknown *_pCtxEntryHead;
	IUnknown *_pCtxFreeList;
	IUnknown *_pServer;
	IUnknown *_pID;
	void *_pVtableAddress;
};

class  CMyIDObject :public IUnknown
{
	SHashChain _pidChain;
	SHashChain _oidChain;
	unsigned int _dwState;
	unsigned int _cRefs;
	IUnknown *_pServer;
	IObjectContext *_pServerCtx;
	_GUID _oid;
	unsigned int _aptID;
	CMyCStdWrapperMarshal *_pStdWrapper;
	CMyClassCStdIdentity *_pStdID;
	unsigned int _cCalls;
	unsigned int _cLocks;
	SHashChain _oidUnpinReqChain;
	unsigned int _dwOidUnpinReqState;
	void *_pvObjectTrackCookie;
};



class CMyClassStdMarshal :public IMarshal
{
public:
	unsigned int _dwFlags;
	int _cIPIDs;
	tagIPIDEntry *_pFirstIPID;
	CMyClassCStdIdentity*  _pStdId_CMyClassStdMarshal;
	IRpcChannelBuffer *_pChnl_CCtxComChnl;
	_GUID _clsidHandler;
	int _cNestedCalls;
	int _cTableRefs;
	unsigned int _dwMarshalTime;
	ULONGLONG *_pSecureRemUnk_IRemUnknown;
	IUnknown *_pAsyncRelease;
	ULONGLONG *_pCtxEntryHead_CtxEntry;
	ULONGLONG *_pCtxFreeList_CtxEntry;
	_RTL_CRITICAL_SECTION _csCtxEntry;
	int _fCsInitialized;
	ULONGLONG *_pPS_CPolicySet;
	CMyIDObject *_pID_CIDObject;
	ULONGLONG *_pRefCache_CRefCache;
	CStdMarshal_DiscSinkNode _discHead_CStdMarshal_DiscSinkNode;
	unsigned int _dwLastCallTime;
};

class CCMyClassClientSecurity :IClientSecurity
{
public:
	CMyClassCStdIdentity*  _pStdId_CCMyClassClientSecurity;
};



class CCMyClassRpcOptions :IRpcOptions
{
public:
	
	CMyClassCStdIdentity*  _pStdId_CCMyClassRpcOptions;
	IUnknown *_pUnkOuter;
} ;

